
import pinecone

def create_pinecone_index():
    pinecone.init(api_key="YOUR_PINECONE_API_KEY", environment="us-west1-gcp")
    index_name = "document-summaries"
    if index_name not in pinecone.list_indexes():
        pinecone.create_index(index_name, dimension=1536)
    return pinecone.Index(index_name)
