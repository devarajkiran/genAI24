
from flask import Flask, render_template, request
from services.document_processor import process_pdf
from services.summarizer import generate_summary

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return "No file uploaded.", 400
    file = request.files['file']
    if not file.filename.endswith('.pdf'):
        return "Only PDF files are supported for now.", 400
    
    # Process the file and extract text
    selected_pages = request.form.getlist('selected_pages')
    text = process_pdf(file, selected_pages)
    
    # Generate summary
    summary = generate_summary(text)
    
    return summary

if __name__ == '__main__':
    app.run(debug=True)
