
import openai
from services.text_preprocessor import split_text_into_chunks
from services.embeddings_generator import generate_embeddings
from services.retriever import retrieve_chunks

def generate_summary(text):
    # Split into chunks and create embeddings
    chunks = split_text_into_chunks(text)
    generate_embeddings(chunks)
    
    # Retrieve relevant content
    query = "Summarize the document."
    summary = retrieve_chunks(query, pinecone_index)
    return summary
