
import openai
from langchain.embeddings.openai import OpenAIEmbeddings
from utils.pinecone_setup import create_pinecone_index

def generate_embeddings(text_chunks):
    embeddings = OpenAIEmbeddings()
    index = create_pinecone_index()
    index.store_texts(text_chunks, embedding=embeddings)
