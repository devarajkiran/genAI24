
from langchain.chains import RetrievalQA

def retrieve_chunks(query, pinecone_index):
    qa = RetrievalQA.from_chain_type(
        llm=openai.ChatCompletion.create,
        chain_type="stuff",
        retriever=pinecone_index.as_retriever()
    )
    result = qa.run(query)
    return result
