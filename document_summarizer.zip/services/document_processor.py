
import PyPDF2

def process_pdf(file, selected_pages):
    selected_pages = [int(p) - 1 for p in selected_pages]  # Convert to 0-based index
    reader = PyPDF2.PdfReader(file)
    extracted_text = ""
    
    for page_num in selected_pages:
        if page_num < len(reader.pages):
            extracted_text += reader.pages[page_num].extract_text()
        else:
            print(f"Page {page_num + 1} out of range.")
    
    return extracted_text
